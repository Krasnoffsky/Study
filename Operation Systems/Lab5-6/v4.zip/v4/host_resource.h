#define IDD_HOSTTEST 101
#define IDC_EDIT1 1000
#define IDC_BTN1 1002


#define IDD_DLGTEST 101
#define IDC_EDIT1 1000
#define IDC_EDIT2 1001
#define IDC_EDIT3 1003
#define IDC_EDIT4 1004
#define IDC_BTN1 1002

